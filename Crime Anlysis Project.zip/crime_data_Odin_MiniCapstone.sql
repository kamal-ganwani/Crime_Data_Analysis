USE crimedataanalysisodinminicapstone;
SELECT * FROM crime_data;

